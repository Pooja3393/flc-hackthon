# education-website
## A static website build for practicing in UI/UX buil in pure JS, HTML and CSS
https://jocular-f467d1.netlify.app/
